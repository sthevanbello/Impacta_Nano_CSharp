﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula10
{
    public class Calculos
    {
        //Método
        public int Somar(int a, int b, int c)
        {
            int resultado = a + b +c;
            return resultado;
        }

        //Método
        public int Subtrair(int a, int b)
        {
            int resultado = a - b;
            return resultado;
        }

    }
}
