﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula13
{
    public class Aluno:CadastroBase
    {
        public string Matricula { get; set; }
    }
}
