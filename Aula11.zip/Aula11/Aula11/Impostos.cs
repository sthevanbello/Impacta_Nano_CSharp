﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula11
{
    public class Impostos
    {
      
       

        public static decimal CalcularISS(string estado, decimal valorServico, bool empresaIndividual)
        {
            decimal porcentagem;
            if (empresaIndividual)
            {
                porcentagem = 0.01m;
            }
            else
            {
                if (estado == "SP")
                {
                    porcentagem = 0.06m;
                }
                else
                {
                    porcentagem = 0.05m;
                }
            }

            decimal valorImposto = valorServico * porcentagem;

            return valorImposto;

        }

        //Modificador de Acesso (public)
        //retorno é um valor (decimal)
        // Nome do Método é CalcularISS
        // Parâmetros: estado (string), valor(decima)
        public static decimal CalcularISS(string estado, decimal valorServico)
        {
            decimal porcentagem;
            if (estado == "SP")
            {
                porcentagem = 0.06m;
            }
            else
            {
                porcentagem = 0.05m;
            }

            decimal valorImposto = valorServico * porcentagem;

            return valorImposto;
        }
    }
}
