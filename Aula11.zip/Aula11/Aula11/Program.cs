﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aula11
{
    class Program
    {
        static void Main(string[] args)
        {
            
            decimal valorIss = Impostos.CalcularISS("SP", 500);
            decimal valorIssIndividual = Impostos.CalcularISS("SP", 500, true);
            
            Console.WriteLine("Valor do ISS em São Paulo: {0:C}", valorIss);
            Console.WriteLine("Valor do ISS em São Paulo para empresa individual: {0:C}",
                valorIssIndividual);

            Console.ReadLine();


        }

    }
}
